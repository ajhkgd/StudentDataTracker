import jsPDF from 'jspdf';
import logoPath from '@assets/download_1752058162086.png';

export function generatePDF(type: string, data: any[]) {
  const doc = new jsPDF();
  
  // Add logo
  try {
    doc.addImage(logoPath, 'PNG', 15, 10, 25, 25);
  } catch (error) {
    console.warn('Could not add logo to PDF:', error);
  }
  
  // Add header text with logo spacing
  doc.setFontSize(16);
  doc.text('Sistem Informasi Siswa', 45, 20);
  doc.setFontSize(12);
  doc.text('MTs Yaspika Karangtawang', 45, 30);
  
  const currentDate = new Date().toLocaleDateString('id-ID');
  doc.setFontSize(10);
  doc.text(`Tanggal: ${currentDate}`, 150, 20);

  switch (type) {
    case 'students':
      generateStudentsPDF(doc, data);
      break;
    case 'attendance':
      generateAttendancePDF(doc, data);
      break;
    case 'incidents':
      generateIncidentsPDF(doc, data);
      break;
    case 'attendance-report':
      generateAttendanceReportPDF(doc, data);
      break;
    case 'incident-report':
      generateIncidentReportPDF(doc, data);
      break;
    default:
      console.error('Unknown PDF type');
      return;
  }

  doc.save(`${type}-${currentDate}.pdf`);
}

function generateStudentsPDF(doc: jsPDF, students: any[]) {
  doc.setFontSize(14);
  doc.text('Data Siswa', 45, 45);

  // Table headers
  const headers = ['No', 'ID', 'Nama', 'Kelas', 'No HP', 'Alamat'];
  let yPosition = 60;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  
  // Draw headers
  doc.text(headers[0], 20, yPosition);
  doc.text(headers[1], 35, yPosition);
  doc.text(headers[2], 55, yPosition);
  doc.text(headers[3], 100, yPosition);
  doc.text(headers[4], 125, yPosition);
  doc.text(headers[5], 155, yPosition);
  
  yPosition += 10;
  doc.setFont('helvetica', 'normal');
  
  // Draw data rows
  students.forEach((student, index) => {
    if (yPosition > 250) {
      doc.addPage();
      // Add logo to new page
      try {
        doc.addImage(logoPath, 'PNG', 15, 10, 25, 25);
      } catch (error) {
        console.warn('Could not add logo to PDF page:', error);
      }
      yPosition = 50;
    }
    
    doc.text((index + 1).toString(), 20, yPosition);
    doc.text(student.id.toString().padStart(3, '0'), 35, yPosition);
    doc.text(student.nama.substring(0, 15), 55, yPosition);
    doc.text(student.kelas, 100, yPosition);
    doc.text(student.noHp || '-', 125, yPosition);
    doc.text((student.alamat || '-').substring(0, 20), 155, yPosition);
    
    yPosition += 8;
  });
}

function generateAttendancePDF(doc: jsPDF, attendance: any[]) {
  doc.setFontSize(14);
  doc.text('Data Kehadiran', 45, 45);

  // Table headers
  const headers = ['No', 'Tanggal', 'Nama', 'Kelas', 'Keterangan'];
  let yPosition = 60;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  
  // Draw headers
  doc.text(headers[0], 20, yPosition);
  doc.text(headers[1], 35, yPosition);
  doc.text(headers[2], 75, yPosition);
  doc.text(headers[3], 120, yPosition);
  doc.text(headers[4], 145, yPosition);
  
  yPosition += 10;
  doc.setFont('helvetica', 'normal');
  
  // Draw data rows
  attendance.forEach((record, index) => {
    if (yPosition > 250) {
      doc.addPage();
      // Add logo to new page
      try {
        doc.addImage(logoPath, 'PNG', 15, 10, 25, 25);
      } catch (error) {
        console.warn('Could not add logo to PDF page:', error);
      }
      yPosition = 50;
    }
    
    doc.text((index + 1).toString(), 20, yPosition);
    doc.text(record.tanggal, 35, yPosition);
    doc.text((record.student?.nama || '-').substring(0, 15), 75, yPosition);
    doc.text(record.student?.kelas || '-', 120, yPosition);
    doc.text(record.keterangan, 145, yPosition);
    
    yPosition += 8;
  });
}

function generateIncidentsPDF(doc: jsPDF, incidents: any[]) {
  doc.setFontSize(14);
  doc.text('Data Kejadian', 45, 45);

  // Table headers
  const headers = ['No', 'Tanggal', 'Nama', 'Kelas', 'Jenis Kejadian'];
  let yPosition = 60;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  
  // Draw headers
  doc.text(headers[0], 20, yPosition);
  doc.text(headers[1], 35, yPosition);
  doc.text(headers[2], 70, yPosition);
  doc.text(headers[3], 115, yPosition);
  doc.text(headers[4], 140, yPosition);
  
  yPosition += 10;
  doc.setFont('helvetica', 'normal');
  
  // Draw data rows
  incidents.forEach((incident, index) => {
    if (yPosition > 250) {
      doc.addPage();
      // Add logo to new page
      try {
        doc.addImage(logoPath, 'PNG', 15, 10, 25, 25);
      } catch (error) {
        console.warn('Could not add logo to PDF page:', error);
      }
      yPosition = 50;
    }
    
    doc.text((index + 1).toString(), 20, yPosition);
    doc.text(incident.tanggal, 35, yPosition);
    doc.text((incident.student?.nama || '-').substring(0, 15), 70, yPosition);
    doc.text(incident.student?.kelas || '-', 115, yPosition);
    doc.text(incident.jenisKejadian, 140, yPosition);
    
    yPosition += 8;
  });
}

function generateAttendanceReportPDF(doc: jsPDF, report: any[]) {
  doc.setFontSize(14);
  doc.text('Rekap Kehadiran', 45, 45);

  // Table headers
  const headers = ['No', 'Nama', 'Sakit', 'Izin', 'Alpa', 'Kesiangan', 'Bolos', 'Status'];
  let yPosition = 60;
  
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  
  // Draw headers
  doc.text(headers[0], 15, yPosition);
  doc.text(headers[1], 25, yPosition);
  doc.text(headers[2], 70, yPosition);
  doc.text(headers[3], 90, yPosition);
  doc.text(headers[4], 110, yPosition);
  doc.text(headers[5], 125, yPosition);
  doc.text(headers[6], 150, yPosition);
  doc.text(headers[7], 170, yPosition);
  
  yPosition += 10;
  doc.setFont('helvetica', 'normal');
  
  // Draw data rows
  report.forEach((record, index) => {
    if (yPosition > 250) {
      doc.addPage();
      // Add logo to new page
      try {
        doc.addImage(logoPath, 'PNG', 15, 10, 25, 25);
      } catch (error) {
        console.warn('Could not add logo to PDF page:', error);
      }
      yPosition = 50;
    }
    
    doc.text((index + 1).toString(), 15, yPosition);
    doc.text(record.nama.substring(0, 15), 25, yPosition);
    doc.text(record.sakit.toString(), 70, yPosition);
    doc.text(record.izin.toString(), 90, yPosition);
    doc.text(record.alpa.toString(), 110, yPosition);
    doc.text(record.kesiangan.toString(), 125, yPosition);
    doc.text(record.bolos.toString(), 150, yPosition);
    doc.text(record.status, 170, yPosition);
    
    yPosition += 8;
  });

  // Add legend
  yPosition += 20;
  doc.setFontSize(10);
  doc.text('Keterangan Status:', 20, yPosition);
  doc.text('• Sangat Baik (0 kali) • Baik (1-3 kali) • Sedang (4-6 kali)', 20, yPosition + 10);
  doc.text('• Kurang (7-15 kali) • Buruk (>15 kali)', 20, yPosition + 20);
}

function generateIncidentReportPDF(doc: jsPDF, report: any[]) {
  doc.setFontSize(14);
  doc.text('Rekap Kejadian', 45, 45);

  // Table headers
  const headers = ['No', 'Nama', 'Total Kejadian', 'Keterangan Kejadian', 'Status'];
  let yPosition = 60;
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  
  // Draw headers
  doc.text(headers[0], 20, yPosition);
  doc.text(headers[1], 35, yPosition);
  doc.text(headers[2], 80, yPosition);
  doc.text(headers[3], 120, yPosition);
  doc.text(headers[4], 170, yPosition);
  
  yPosition += 10;
  doc.setFont('helvetica', 'normal');
  
  // Draw data rows
  report.forEach((record, index) => {
    if (yPosition > 250) {
      doc.addPage();
      // Add logo to new page
      try {
        doc.addImage(logoPath, 'PNG', 15, 10, 25, 25);
      } catch (error) {
        console.warn('Could not add logo to PDF page:', error);
      }
      yPosition = 50;
    }
    
    doc.text((index + 1).toString(), 20, yPosition);
    doc.text(record.nama.substring(0, 15), 35, yPosition);
    doc.text(record.totalKejadian.toString(), 80, yPosition);
    doc.text(record.keteranganKejadian.substring(0, 20), 120, yPosition);
    doc.text(record.status, 170, yPosition);
    
    yPosition += 8;
  });
}
