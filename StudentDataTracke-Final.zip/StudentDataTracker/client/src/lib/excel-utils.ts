import * as XLSX from 'xlsx';

export async function parseExcelData(file: File): Promise<any[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        
        // Get first worksheet
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        
        // Convert to JSON
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
        
        // Skip header row and map to student format
        const students = (jsonData as any[]).slice(1).map((row: any[]) => ({
          nama: row[0] || '',
          kelas: row[1] || '',
          noHp: row[2] || '',
          alamat: row[3] || '',
        })).filter(student => student.nama); // Filter out empty rows
        
        resolve(students);
      } catch (error) {
        reject(error);
      }
    };
    
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsArrayBuffer(file);
  });
}

export function downloadExcelTemplate() {
  const template = [
    ['Nama', 'Kelas', 'No HP', 'Alamat'],
    ['Ahmad Ridwan', '7A', '0812-3456-7890', 'Jl. Merdeka No. 123'],
    ['Siti Aisyah', '7A', '0856-7890-1234', 'Jl. Pahlawan No. 45'],
  ];
  
  const worksheet = XLSX.utils.aoa_to_sheet(template);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Template Data Siswa');
  
  XLSX.writeFile(workbook, 'template-data-siswa.xlsx');
}
