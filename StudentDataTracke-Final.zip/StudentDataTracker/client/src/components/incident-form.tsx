import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { insertIncidentSchema, type Incident, type InsertIncident, type Student } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

const JENIS_KEJADIAN = [
  "Berkelahi", "Merokok", "Pacaran", "Bullying", "Tidak Sholat", 
  "Tidak Ikut Upacara", "Pakaian", "Melawan Guru", "Lainnya"
];

interface IncidentFormProps {
  incident?: Incident & { student: Student };
  onSuccess?: () => void;
}

export default function IncidentForm({ incident, onSuccess }: IncidentFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isOpen, setIsOpen] = useState(true);
  const [showOtherField, setShowOtherField] = useState(false);

  const { data: students = [] } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  const form = useForm<InsertIncident>({
    resolver: zodResolver(insertIncidentSchema),
    defaultValues: {
      studentId: incident?.studentId || 0,
      jenisKejadian: incident?.jenisKejadian || "",
      deskripsi: incident?.deskripsi || "",
      tanggal: incident?.tanggal || format(new Date(), "yyyy-MM-dd"),
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: InsertIncident) => {
      if (incident) {
        return await apiRequest("PUT", `/api/incidents/${incident.id}`, data);
      } else {
        return await apiRequest("POST", "/api/incidents", data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/incidents"] });
      toast({
        title: incident ? "Data kejadian berhasil diupdate" : "Data kejadian berhasil ditambahkan",
      });
      onSuccess?.();
      setIsOpen(false);
    },
    onError: () => {
      toast({
        title: "Gagal menyimpan data kejadian",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertIncident) => {
    mutation.mutate(data);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="studentId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Nama Siswa</FormLabel>
              <Select onValueChange={(value) => field.onChange(parseInt(value))} defaultValue={field.value?.toString()}>
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih Siswa" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {students.map(student => (
                    <SelectItem key={student.id} value={student.id.toString()}>
                      {student.nama} - {student.kelas}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="jenisKejadian"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Jenis Kejadian</FormLabel>
              <Select 
                onValueChange={(value) => {
                  field.onChange(value);
                  setShowOtherField(value === "Lainnya");
                }} 
                defaultValue={field.value}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Pilih Jenis Kejadian" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {JENIS_KEJADIAN.map(jenis => (
                    <SelectItem key={jenis} value={jenis}>
                      {jenis}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        {showOtherField && (
          <FormField
            control={form.control}
            name="jenisKejadian"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Kejadian Lainnya</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="Jelaskan kejadian lainnya" 
                    onChange={(e) => field.onChange(e.target.value)}
                    value={field.value === "Lainnya" ? "" : field.value}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        )}

        <FormField
          control={form.control}
          name="deskripsi"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Deskripsi</FormLabel>
              <FormControl>
                <Textarea placeholder="Deskripsi detail kejadian" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="tanggal"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Tanggal</FormLabel>
              <FormControl>
                <Input type="date" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-3 pt-4">
          <Button 
            type="button" 
            variant="outline" 
            onClick={() => setIsOpen(false)}
          >
            Batal
          </Button>
          <Button 
            type="submit" 
            disabled={mutation.isPending}
          >
            {mutation.isPending ? "Menyimpan..." : "Simpan"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
