import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Download, Plus, Upload, Search, User, FileText, AlertTriangle, BarChart3 } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import StudentForm from "@/components/student-form";
import AttendanceForm from "@/components/attendance-form";
import IncidentForm from "@/components/incident-form";
import { generatePDF } from "@/lib/pdf-utils";
import { parseExcelData } from "@/lib/excel-utils";
import logoPath from "@assets/download_1752056802404.png";
import type { Student, Attendance, Incident, AttendanceReport, IncidentReport } from "@shared/schema";

const KELAS_OPTIONS = ["7A", "7B", "8A", "8B", "9A", "9B"];

const KETERANGAN_ATTENDANCE = [
  { value: "sakit", label: "Sakit", color: "bg-yellow-100 text-yellow-800" },
  { value: "izin", label: "Izin", color: "bg-blue-100 text-blue-800" },
  { value: "alpa", label: "Alpa", color: "bg-red-100 text-red-800" },
  { value: "kesiangan", label: "Kesiangan", color: "bg-orange-100 text-orange-800" },
  { value: "bolos", label: "Bolos", color: "bg-purple-100 text-purple-800" },
];

const JENIS_KEJADIAN = [
  "Berkelahi", "Merokok", "Pacaran", "Bullying", "Tidak Sholat", 
  "Tidak Ikut Upacara", "Pakaian", "Melawan Guru", "Lainnya"
];

const STATUS_COLORS = {
  "Sangat Baik": "bg-green-100 text-green-800",
  "Baik": "bg-blue-100 text-blue-800",
  "Sedang": "bg-gray-100 text-gray-800",
  "Kurang": "bg-yellow-100 text-yellow-800",
  "Buruk": "bg-red-100 text-red-800",
};

export default function Home() {
  const [activeTab, setActiveTab] = useState("data-siswa");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedClass, setSelectedClass] = useState<string>("");
  const [attendanceFilters, setAttendanceFilters] = useState({
    kelas: "all",
    startDate: "",
    endDate: "",
  });
  const [incidentFilters, setIncidentFilters] = useState({
    kelas: "all",
    jenisKejadian: "all-incidents",
    tanggal: "",
  });
  const [reportFilters, setReportFilters] = useState({
    kelas: "all",
    startDate: "",
    endDate: "",
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Queries
  const { data: students = [], isLoading: studentsLoading } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  const { data: attendance = [], isLoading: attendanceLoading } = useQuery<(Attendance & { student: Student })[]>({
    queryKey: ["/api/attendance", attendanceFilters],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (attendanceFilters.kelas && attendanceFilters.kelas !== "all") params.append("kelas", attendanceFilters.kelas);
      if (attendanceFilters.startDate) params.append("startDate", attendanceFilters.startDate);
      if (attendanceFilters.endDate) params.append("endDate", attendanceFilters.endDate);
      
      const response = await fetch(`/api/attendance?${params}`);
      return response.json();
    },
  });

  const { data: incidents = [], isLoading: incidentsLoading } = useQuery<(Incident & { student: Student })[]>({
    queryKey: ["/api/incidents", incidentFilters],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (incidentFilters.kelas && incidentFilters.kelas !== "all") params.append("kelas", incidentFilters.kelas);
      if (incidentFilters.jenisKejadian && incidentFilters.jenisKejadian !== "all-incidents") params.append("jenisKejadian", incidentFilters.jenisKejadian);
      if (incidentFilters.tanggal) params.append("tanggal", incidentFilters.tanggal);
      
      const response = await fetch(`/api/incidents?${params}`);
      return response.json();
    },
  });

  const { data: attendanceReport = [], isLoading: attendanceReportLoading } = useQuery<AttendanceReport[]>({
    queryKey: ["/api/reports/attendance", reportFilters],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (reportFilters.kelas && reportFilters.kelas !== "all") params.append("kelas", reportFilters.kelas);
      if (reportFilters.startDate) params.append("startDate", reportFilters.startDate);
      if (reportFilters.endDate) params.append("endDate", reportFilters.endDate);
      
      const response = await fetch(`/api/reports/attendance?${params}`);
      return response.json();
    },
    enabled: false,
  });

  const { data: incidentReport = [], isLoading: incidentReportLoading } = useQuery<IncidentReport[]>({
    queryKey: ["/api/reports/incidents", reportFilters],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (reportFilters.kelas && reportFilters.kelas !== "all") params.append("kelas", reportFilters.kelas);
      if (reportFilters.startDate) params.append("startDate", reportFilters.startDate);
      if (reportFilters.endDate) params.append("endDate", reportFilters.endDate);
      
      const response = await fetch(`/api/reports/incidents?${params}`);
      return response.json();
    },
    enabled: false,
  });

  // Mutations
  const deleteStudentMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/students/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      toast({ title: "Siswa berhasil dihapus" });
    },
    onError: () => {
      toast({ title: "Gagal menghapus siswa", variant: "destructive" });
    },
  });

  const deleteAttendanceMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/attendance/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/attendance"] });
      toast({ title: "Data kehadiran berhasil dihapus" });
    },
    onError: () => {
      toast({ title: "Gagal menghapus data kehadiran", variant: "destructive" });
    },
  });

  const deleteIncidentMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/incidents/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/incidents"] });
      toast({ title: "Data kejadian berhasil dihapus" });
    },
    onError: () => {
      toast({ title: "Gagal menghapus data kejadian", variant: "destructive" });
    },
  });

  const bulkImportMutation = useMutation({
    mutationFn: async (studentsData: any[]) => {
      const response = await apiRequest("POST", "/api/students/bulk-import", { students: studentsData });
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/students"] });
      toast({ 
        title: `Import berhasil`, 
        description: `${data.success} siswa berhasil diimport, ${data.errors} error` 
      });
    },
    onError: () => {
      toast({ title: "Gagal mengimport data", variant: "destructive" });
    },
  });

  // Filter students based on search and class
  const filteredStudents = students.filter(student => {
    const matchesSearch = student.nama.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesClass = !selectedClass || selectedClass === "all" || student.kelas === selectedClass;
    return matchesSearch && matchesClass;
  });

  // Generate reports
  const generateAttendanceReport = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/reports/attendance", reportFilters] });
  };

  const generateIncidentReport = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/reports/incidents", reportFilters] });
  };

  // Export to PDF
  const exportToPDF = (type: string, data: any[]) => {
    generatePDF(type, data);
    toast({ title: "PDF berhasil diexport" });
  };

  // Handle Excel import
  const handleExcelImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    parseExcelData(file).then((data) => {
      bulkImportMutation.mutate(data);
    }).catch(() => {
      toast({ title: "Gagal membaca file Excel", variant: "destructive" });
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-primary text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <img 
                src={logoPath} 
                alt="Logo MTs Yaspika Karangtawang" 
                className="w-16 h-16 object-contain"
              />
              <div>
                <h1 className="text-2xl font-bold">Sistem Informasi Siswa</h1>
                <p className="text-blue-100">MTs Yaspika Karangtawang</p>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-4">
              <span className="text-sm">Admin Dashboard</span>
              <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                <User className="w-5 h-5" />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="data-siswa" className="flex items-center gap-2">
              <User className="w-4 h-4" />
              Data Siswa
            </TabsTrigger>
            <TabsTrigger value="kehadiran" className="flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Kehadiran
            </TabsTrigger>
            <TabsTrigger value="kejadian" className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Kejadian
            </TabsTrigger>
            <TabsTrigger value="rekap" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Rekap
            </TabsTrigger>
          </TabsList>

          {/* Data Siswa Tab */}
          <TabsContent value="data-siswa">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
                  <div>
                    <CardTitle>Data Siswa</CardTitle>
                    <p className="text-sm text-muted-foreground">Kelola data siswa MTs Yaspika Karangtawang</p>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <Button 
                      variant="outline"
                      onClick={() => exportToPDF("students", filteredStudents)}
                      className="bg-green-600 text-white hover:bg-green-700"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Export PDF
                    </Button>
                    <div className="relative">
                      <input
                        type="file"
                        accept=".xlsx,.xls"
                        onChange={handleExcelImport}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      />
                      <Button variant="outline" className="bg-orange-600 text-white hover:bg-orange-700">
                        <Upload className="w-4 h-4 mr-2" />
                        Import Excel
                      </Button>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button>
                          <Plus className="w-4 h-4 mr-2" />
                          Tambah Siswa
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Tambah Data Siswa</DialogTitle>
                        </DialogHeader>
                        <StudentForm />
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* Search and Filters */}
                <div className="flex flex-col md:flex-row gap-4 mb-6">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Cari nama siswa..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Select value={selectedClass} onValueChange={setSelectedClass}>
                    <SelectTrigger className="w-48">
                      <SelectValue placeholder="Semua Kelas" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Semua Kelas</SelectItem>
                      {KELAS_OPTIONS.map(kelas => (
                        <SelectItem key={kelas} value={kelas}>{kelas}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Students Table */}
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Nama</TableHead>
                        <TableHead>Kelas</TableHead>
                        <TableHead>No HP</TableHead>
                        <TableHead>Alamat</TableHead>
                        <TableHead>Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {studentsLoading ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center">Loading...</TableCell>
                        </TableRow>
                      ) : filteredStudents.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center">Tidak ada data siswa</TableCell>
                        </TableRow>
                      ) : (
                        filteredStudents.map((student) => (
                          <TableRow key={student.id}>
                            <TableCell>{student.id.toString().padStart(3, '0')}</TableCell>
                            <TableCell className="font-medium">{student.nama}</TableCell>
                            <TableCell>{student.kelas}</TableCell>
                            <TableCell>{student.noHp || '-'}</TableCell>
                            <TableCell>{student.alamat || '-'}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Dialog>
                                  <DialogTrigger asChild>
                                    <Button variant="ghost" size="sm">Edit</Button>
                                  </DialogTrigger>
                                  <DialogContent>
                                    <DialogHeader>
                                      <DialogTitle>Edit Data Siswa</DialogTitle>
                                    </DialogHeader>
                                    <StudentForm student={student} />
                                  </DialogContent>
                                </Dialog>
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="text-red-600 hover:text-red-700"
                                  onClick={() => deleteStudentMutation.mutate(student.id)}
                                >
                                  Hapus
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Kehadiran Tab */}
          <TabsContent value="kehadiran">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
                  <div>
                    <CardTitle>Kehadiran Siswa</CardTitle>
                    <p className="text-sm text-muted-foreground">Catat dan kelola kehadiran siswa</p>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline"
                      onClick={() => exportToPDF("attendance", attendance)}
                      className="bg-green-600 text-white hover:bg-green-700"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Export PDF
                    </Button>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button>
                          <Plus className="w-4 h-4 mr-2" />
                          Catat Ketidakhadiran
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Catat Ketidakhadiran</DialogTitle>
                        </DialogHeader>
                        <AttendanceForm />
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* Filters */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div>
                    <Label>Kelas</Label>
                    <Select 
                      value={attendanceFilters.kelas} 
                      onValueChange={(value) => setAttendanceFilters({...attendanceFilters, kelas: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Semua Kelas" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Semua Kelas</SelectItem>
                        {KELAS_OPTIONS.map(kelas => (
                          <SelectItem key={kelas} value={kelas}>{kelas}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Tanggal Mulai</Label>
                    <Input 
                      type="date" 
                      value={attendanceFilters.startDate}
                      onChange={(e) => setAttendanceFilters({...attendanceFilters, startDate: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label>Tanggal Akhir</Label>
                    <Input 
                      type="date" 
                      value={attendanceFilters.endDate}
                      onChange={(e) => setAttendanceFilters({...attendanceFilters, endDate: e.target.value})}
                    />
                  </div>
                </div>

                {/* Attendance Table */}
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Tanggal</TableHead>
                        <TableHead>Nama</TableHead>
                        <TableHead>Kelas</TableHead>
                        <TableHead>Keterangan</TableHead>
                        <TableHead>Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {attendanceLoading ? (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center">Loading...</TableCell>
                        </TableRow>
                      ) : attendance.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center">Tidak ada data kehadiran</TableCell>
                        </TableRow>
                      ) : (
                        attendance.map((record) => {
                          const keteranganInfo = KETERANGAN_ATTENDANCE.find(k => k.value === record.keterangan);
                          return (
                            <TableRow key={record.id}>
                              <TableCell>{record.tanggal}</TableCell>
                              <TableCell className="font-medium">{record.student?.nama}</TableCell>
                              <TableCell>{record.student?.kelas}</TableCell>
                              <TableCell>
                                <Badge className={keteranganInfo?.color}>
                                  {keteranganInfo?.label}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <div className="flex gap-2">
                                  <Dialog>
                                    <DialogTrigger asChild>
                                      <Button variant="ghost" size="sm">Edit</Button>
                                    </DialogTrigger>
                                    <DialogContent>
                                      <DialogHeader>
                                        <DialogTitle>Edit Kehadiran</DialogTitle>
                                      </DialogHeader>
                                      <AttendanceForm attendance={record} />
                                    </DialogContent>
                                  </Dialog>
                                  <Button 
                                    variant="ghost" 
                                    size="sm" 
                                    className="text-red-600 hover:text-red-700"
                                    onClick={() => deleteAttendanceMutation.mutate(record.id)}
                                  >
                                    Hapus
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          );
                        })
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Kejadian Tab */}
          <TabsContent value="kejadian">
            <Card>
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
                  <div>
                    <CardTitle>Kejadian Siswa</CardTitle>
                    <p className="text-sm text-muted-foreground">Catat dan kelola kejadian siswa</p>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline"
                      onClick={() => exportToPDF("incidents", incidents)}
                      className="bg-green-600 text-white hover:bg-green-700"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Export PDF
                    </Button>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button>
                          <Plus className="w-4 h-4 mr-2" />
                          Catat Kejadian
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Catat Kejadian</DialogTitle>
                        </DialogHeader>
                        <IncidentForm />
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* Filters */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div>
                    <Label>Kelas</Label>
                    <Select 
                      value={incidentFilters.kelas} 
                      onValueChange={(value) => setIncidentFilters({...incidentFilters, kelas: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Semua Kelas" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Semua Kelas</SelectItem>
                        {KELAS_OPTIONS.map(kelas => (
                          <SelectItem key={kelas} value={kelas}>{kelas}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Jenis Kejadian</Label>
                    <Select 
                      value={incidentFilters.jenisKejadian} 
                      onValueChange={(value) => setIncidentFilters({...incidentFilters, jenisKejadian: value})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Semua Kejadian" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all-incidents">Semua Kejadian</SelectItem>
                        {JENIS_KEJADIAN.map(jenis => (
                          <SelectItem key={jenis} value={jenis}>{jenis}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Tanggal</Label>
                    <Input 
                      type="date" 
                      value={incidentFilters.tanggal}
                      onChange={(e) => setIncidentFilters({...incidentFilters, tanggal: e.target.value})}
                    />
                  </div>
                </div>

                {/* Incidents Table */}
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Tanggal</TableHead>
                        <TableHead>Nama</TableHead>
                        <TableHead>Kelas</TableHead>
                        <TableHead>Jenis Kejadian</TableHead>
                        <TableHead>Deskripsi</TableHead>
                        <TableHead>Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {incidentsLoading ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center">Loading...</TableCell>
                        </TableRow>
                      ) : incidents.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center">Tidak ada data kejadian</TableCell>
                        </TableRow>
                      ) : (
                        incidents.map((incident) => (
                          <TableRow key={incident.id}>
                            <TableCell>{incident.tanggal}</TableCell>
                            <TableCell className="font-medium">{incident.student?.nama}</TableCell>
                            <TableCell>{incident.student?.kelas}</TableCell>
                            <TableCell>
                              <Badge variant="outline">{incident.jenisKejadian}</Badge>
                            </TableCell>
                            <TableCell>{incident.deskripsi || '-'}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Dialog>
                                  <DialogTrigger asChild>
                                    <Button variant="ghost" size="sm">Edit</Button>
                                  </DialogTrigger>
                                  <DialogContent>
                                    <DialogHeader>
                                      <DialogTitle>Edit Kejadian</DialogTitle>
                                    </DialogHeader>
                                    <IncidentForm incident={incident} />
                                  </DialogContent>
                                </Dialog>
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="text-red-600 hover:text-red-700"
                                  onClick={() => deleteIncidentMutation.mutate(incident.id)}
                                >
                                  Hapus
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Rekap Tab */}
          <TabsContent value="rekap">
            <div className="space-y-8">
              {/* Rekap Kehadiran */}
              <Card>
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
                    <div>
                      <CardTitle>Rekap Kehadiran</CardTitle>
                      <p className="text-sm text-muted-foreground">Laporan kehadiran siswa berdasarkan periode</p>
                    </div>
                    <Button 
                      variant="outline"
                      onClick={() => exportToPDF("attendance-report", attendanceReport)}
                      className="bg-green-600 text-white hover:bg-green-700"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Export PDF
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {/* Filters */}
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                    <div>
                      <Label>Kelas</Label>
                      <Select 
                        value={reportFilters.kelas} 
                        onValueChange={(value) => setReportFilters({...reportFilters, kelas: value})}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih Kelas" />
                        </SelectTrigger>
                        <SelectContent>
                          {KELAS_OPTIONS.map(kelas => (
                            <SelectItem key={kelas} value={kelas}>{kelas}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Tanggal Mulai</Label>
                      <Input 
                        type="date" 
                        value={reportFilters.startDate}
                        onChange={(e) => setReportFilters({...reportFilters, startDate: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label>Tanggal Akhir</Label>
                      <Input 
                        type="date" 
                        value={reportFilters.endDate}
                        onChange={(e) => setReportFilters({...reportFilters, endDate: e.target.value})}
                      />
                    </div>
                    <div className="flex items-end">
                      <Button onClick={generateAttendanceReport} className="w-full">
                        Lihat Data
                      </Button>
                    </div>
                  </div>

                  {/* Attendance Report Table */}
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>No</TableHead>
                          <TableHead>Nama</TableHead>
                          <TableHead className="text-center">Sakit</TableHead>
                          <TableHead className="text-center">Izin</TableHead>
                          <TableHead className="text-center">Alpa</TableHead>
                          <TableHead className="text-center">Kesiangan</TableHead>
                          <TableHead className="text-center">Bolos</TableHead>
                          <TableHead className="text-center">Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {attendanceReportLoading ? (
                          <TableRow>
                            <TableCell colSpan={8} className="text-center">Loading...</TableCell>
                          </TableRow>
                        ) : attendanceReport.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={8} className="text-center">Tidak ada data. Pilih filter dan klik "Lihat Data"</TableCell>
                          </TableRow>
                        ) : (
                          attendanceReport.map((record, index) => (
                            <TableRow key={record.studentId}>
                              <TableCell>{index + 1}</TableCell>
                              <TableCell className="font-medium">{record.nama}</TableCell>
                              <TableCell className="text-center">{record.sakit}</TableCell>
                              <TableCell className="text-center">{record.izin}</TableCell>
                              <TableCell className="text-center">{record.alpa}</TableCell>
                              <TableCell className="text-center">{record.kesiangan}</TableCell>
                              <TableCell className="text-center">{record.bolos}</TableCell>
                              <TableCell className="text-center">
                                <Badge className={STATUS_COLORS[record.status as keyof typeof STATUS_COLORS]}>
                                  {record.status}
                                </Badge>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>

                  {/* Legend */}
                  <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                    <h4 className="text-sm font-medium text-gray-900 mb-3">Keterangan Status:</h4>
                    <div className="flex flex-wrap gap-4 text-xs">
                      <div className="flex items-center">
                        <span className="w-3 h-3 bg-green-500 rounded-full mr-2"></span>
                        <span>Sangat Baik (0 kali)</span>
                      </div>
                      <div className="flex items-center">
                        <span className="w-3 h-3 bg-blue-500 rounded-full mr-2"></span>
                        <span>Baik (1-3 kali)</span>
                      </div>
                      <div className="flex items-center">
                        <span className="w-3 h-3 bg-gray-500 rounded-full mr-2"></span>
                        <span>Sedang (4-6 kali)</span>
                      </div>
                      <div className="flex items-center">
                        <span className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></span>
                        <span>Kurang (7-15 kali)</span>
                      </div>
                      <div className="flex items-center">
                        <span className="w-3 h-3 bg-red-500 rounded-full mr-2"></span>
                        <span>Buruk ({'>'}15 kali)</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Rekap Kejadian */}
              <Card>
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
                    <div>
                      <CardTitle>Rekap Kejadian</CardTitle>
                      <p className="text-sm text-muted-foreground">Laporan kejadian siswa berdasarkan periode</p>
                    </div>
                    <Button 
                      variant="outline"
                      onClick={() => exportToPDF("incident-report", incidentReport)}
                      className="bg-green-600 text-white hover:bg-green-700"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Export PDF
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {/* Filters */}
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                    <div>
                      <Label>Kelas</Label>
                      <Select 
                        value={reportFilters.kelas} 
                        onValueChange={(value) => setReportFilters({...reportFilters, kelas: value})}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Pilih Kelas" />
                        </SelectTrigger>
                        <SelectContent>
                          {KELAS_OPTIONS.map(kelas => (
                            <SelectItem key={kelas} value={kelas}>{kelas}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Tanggal Mulai</Label>
                      <Input 
                        type="date" 
                        value={reportFilters.startDate}
                        onChange={(e) => setReportFilters({...reportFilters, startDate: e.target.value})}
                      />
                    </div>
                    <div>
                      <Label>Tanggal Akhir</Label>
                      <Input 
                        type="date" 
                        value={reportFilters.endDate}
                        onChange={(e) => setReportFilters({...reportFilters, endDate: e.target.value})}
                      />
                    </div>
                    <div className="flex items-end">
                      <Button onClick={generateIncidentReport} className="w-full">
                        Lihat Data
                      </Button>
                    </div>
                  </div>

                  {/* Incident Report Table */}
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>No</TableHead>
                          <TableHead>Nama</TableHead>
                          <TableHead className="text-center">Total Kejadian</TableHead>
                          <TableHead>Keterangan Kejadian</TableHead>
                          <TableHead className="text-center">Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {incidentReportLoading ? (
                          <TableRow>
                            <TableCell colSpan={5} className="text-center">Loading...</TableCell>
                          </TableRow>
                        ) : incidentReport.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={5} className="text-center">Tidak ada data. Pilih filter dan klik "Lihat Data"</TableCell>
                          </TableRow>
                        ) : (
                          incidentReport.map((record, index) => (
                            <TableRow key={record.studentId}>
                              <TableCell>{index + 1}</TableCell>
                              <TableCell className="font-medium">{record.nama}</TableCell>
                              <TableCell className="text-center">{record.totalKejadian}</TableCell>
                              <TableCell>{record.keteranganKejadian}</TableCell>
                              <TableCell className="text-center">
                                <Badge className={STATUS_COLORS[record.status as keyof typeof STATUS_COLORS]}>
                                  {record.status}
                                </Badge>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer */}
      <footer className="mt-8 py-4 border-t bg-gray-50 dark:bg-gray-900">
        <div className="container mx-auto px-4">
          <p className="text-center text-sm text-gray-600 dark:text-gray-400">
            Created by Herdiyana
          </p>
        </div>
      </footer>
    </div>
  );
}
