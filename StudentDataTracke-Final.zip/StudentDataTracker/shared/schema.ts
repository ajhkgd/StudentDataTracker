import { pgTable, text, serial, integer, timestamp, varchar, date } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  nama: varchar("nama", { length: 255 }).notNull(),
  kelas: varchar("kelas", { length: 10 }).notNull(),
  noHp: varchar("no_hp", { length: 20 }),
  alamat: text("alamat"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").references(() => students.id).notNull(),
  tanggal: date("tanggal").notNull(),
  keterangan: varchar("keterangan", { length: 20 }).notNull(), // sakit, izin, alpa, kesiangan, bolos
  createdAt: timestamp("created_at").defaultNow(),
});

export const incidents = pgTable("incidents", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").references(() => students.id).notNull(),
  jenisKejadian: varchar("jenis_kejadian", { length: 50 }).notNull(),
  deskripsi: text("deskripsi"),
  tanggal: date("tanggal").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const studentsRelations = relations(students, ({ many }) => ({
  attendance: many(attendance),
  incidents: many(incidents),
}));

export const attendanceRelations = relations(attendance, ({ one }) => ({
  student: one(students, {
    fields: [attendance.studentId],
    references: [students.id],
  }),
}));

export const incidentsRelations = relations(incidents, ({ one }) => ({
  student: one(students, {
    fields: [incidents.studentId],
    references: [students.id],
  }),
}));

// Insert schemas
export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
  createdAt: true,
});

export const insertAttendanceSchema = createInsertSchema(attendance).omit({
  id: true,
  createdAt: true,
});

export const insertIncidentSchema = createInsertSchema(incidents).omit({
  id: true,
  createdAt: true,
});

// Types
export type Student = typeof students.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;
export type Attendance = typeof attendance.$inferSelect;
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type Incident = typeof incidents.$inferSelect;
export type InsertIncident = z.infer<typeof insertIncidentSchema>;

// Custom types for reports
export type AttendanceReport = {
  studentId: number;
  nama: string;
  sakit: number;
  izin: number;
  alpa: number;
  kesiangan: number;
  bolos: number;
  status: string;
};

export type IncidentReport = {
  studentId: number;
  nama: string;
  totalKejadian: number;
  keteranganKejadian: string;
  status: string;
};
