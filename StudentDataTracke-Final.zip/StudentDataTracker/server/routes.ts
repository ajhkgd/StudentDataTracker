import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertStudentSchema, insertAttendanceSchema, insertIncidentSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Students routes
  app.get("/api/students", async (req, res) => {
    try {
      const students = await storage.getStudents();
      res.json(students);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch students" });
    }
  });

  app.get("/api/students/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const student = await storage.getStudent(id);
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      res.json(student);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch student" });
    }
  });

  app.post("/api/students", async (req, res) => {
    try {
      const validatedData = insertStudentSchema.parse(req.body);
      const student = await storage.createStudent(validatedData);
      res.status(201).json(student);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create student" });
    }
  });

  app.put("/api/students/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertStudentSchema.partial().parse(req.body);
      const student = await storage.updateStudent(id, validatedData);
      res.json(student);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update student" });
    }
  });

  app.delete("/api/students/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteStudent(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete student" });
    }
  });

  app.get("/api/students/class/:kelas", async (req, res) => {
    try {
      const { kelas } = req.params;
      const students = await storage.getStudentsByClass(kelas);
      res.json(students);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch students by class" });
    }
  });

  // Attendance routes
  app.get("/api/attendance", async (req, res) => {
    try {
      const { kelas, startDate, endDate } = req.query;
      const filters = {
        kelas: kelas as string,
        startDate: startDate as string,
        endDate: endDate as string,
      };
      
      const attendance = filters.kelas || filters.startDate || filters.endDate
        ? await storage.getAttendanceByFilters(filters)
        : await storage.getAttendance();
      
      res.json(attendance);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch attendance" });
    }
  });

  app.post("/api/attendance", async (req, res) => {
    try {
      const validatedData = insertAttendanceSchema.parse(req.body);
      const attendance = await storage.createAttendance(validatedData);
      res.status(201).json(attendance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create attendance record" });
    }
  });

  app.put("/api/attendance/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertAttendanceSchema.partial().parse(req.body);
      const attendance = await storage.updateAttendance(id, validatedData);
      res.json(attendance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update attendance record" });
    }
  });

  app.delete("/api/attendance/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteAttendance(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete attendance record" });
    }
  });

  // Incidents routes
  app.get("/api/incidents", async (req, res) => {
    try {
      const { kelas, jenisKejadian, tanggal } = req.query;
      const filters = {
        kelas: kelas as string,
        jenisKejadian: jenisKejadian as string,
        tanggal: tanggal as string,
      };
      
      const incidents = filters.kelas || filters.jenisKejadian || filters.tanggal
        ? await storage.getIncidentsByFilters(filters)
        : await storage.getIncidents();
      
      res.json(incidents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch incidents" });
    }
  });

  app.post("/api/incidents", async (req, res) => {
    try {
      const validatedData = insertIncidentSchema.parse(req.body);
      const incident = await storage.createIncident(validatedData);
      res.status(201).json(incident);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create incident record" });
    }
  });

  app.put("/api/incidents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertIncidentSchema.partial().parse(req.body);
      const incident = await storage.updateIncident(id, validatedData);
      res.json(incident);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update incident record" });
    }
  });

  app.delete("/api/incidents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteIncident(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete incident record" });
    }
  });

  // Reports routes
  app.get("/api/reports/attendance", async (req, res) => {
    try {
      const { kelas, startDate, endDate } = req.query;
      const filters = {
        kelas: kelas as string,
        startDate: startDate as string,
        endDate: endDate as string,
      };
      
      const report = await storage.getAttendanceReport(filters);
      res.json(report);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate attendance report" });
    }
  });

  app.get("/api/reports/incidents", async (req, res) => {
    try {
      const { kelas, startDate, endDate } = req.query;
      const filters = {
        kelas: kelas as string,
        startDate: startDate as string,
        endDate: endDate as string,
      };
      
      const report = await storage.getIncidentReport(filters);
      res.json(report);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate incident report" });
    }
  });

  // Bulk import endpoint
  app.post("/api/students/bulk-import", async (req, res) => {
    try {
      const { students: studentsData } = req.body;
      
      if (!Array.isArray(studentsData)) {
        return res.status(400).json({ message: "Invalid data format" });
      }

      const results = [];
      const errors = [];

      for (let i = 0; i < studentsData.length; i++) {
        try {
          const validatedData = insertStudentSchema.parse(studentsData[i]);
          const student = await storage.createStudent(validatedData);
          results.push(student);
        } catch (error) {
          errors.push({ row: i + 1, error: error instanceof z.ZodError ? error.errors : "Invalid data" });
        }
      }

      res.json({
        success: results.length,
        errors: errors.length,
        results,
        errorDetails: errors,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to import students" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
