import { 
  students, 
  attendance, 
  incidents,
  type Student, 
  type InsertStudent,
  type Attendance,
  type InsertAttendance,
  type Incident,
  type InsertIncident,
  type AttendanceReport,
  type IncidentReport
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, sql, desc } from "drizzle-orm";

export interface IStorage {
  // Students
  getStudents(): Promise<Student[]>;
  getStudent(id: number): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: number, student: Partial<InsertStudent>): Promise<Student>;
  deleteStudent(id: number): Promise<void>;
  getStudentsByClass(kelas: string): Promise<Student[]>;

  // Attendance
  getAttendance(): Promise<(Attendance & { student: Student })[]>;
  getAttendanceByFilters(filters: { kelas?: string; startDate?: string; endDate?: string }): Promise<(Attendance & { student: Student })[]>;
  createAttendance(attendanceData: InsertAttendance): Promise<Attendance>;
  updateAttendance(id: number, attendanceData: Partial<InsertAttendance>): Promise<Attendance>;
  deleteAttendance(id: number): Promise<void>;

  // Incidents
  getIncidents(): Promise<(Incident & { student: Student })[]>;
  getIncidentsByFilters(filters: { kelas?: string; jenisKejadian?: string; tanggal?: string }): Promise<(Incident & { student: Student })[]>;
  createIncident(incident: InsertIncident): Promise<Incident>;
  updateIncident(id: number, incident: Partial<InsertIncident>): Promise<Incident>;
  deleteIncident(id: number): Promise<void>;

  // Reports
  getAttendanceReport(filters: { kelas?: string; startDate?: string; endDate?: string }): Promise<AttendanceReport[]>;
  getIncidentReport(filters: { kelas?: string; startDate?: string; endDate?: string }): Promise<IncidentReport[]>;
}

export class DatabaseStorage implements IStorage {
  // Students
  async getStudents(): Promise<Student[]> {
    return await db.select().from(students).orderBy(students.nama);
  }

  async getStudent(id: number): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.id, id));
    return student || undefined;
  }

  async createStudent(student: InsertStudent): Promise<Student> {
    const [newStudent] = await db.insert(students).values(student).returning();
    return newStudent;
  }

  async updateStudent(id: number, student: Partial<InsertStudent>): Promise<Student> {
    const [updatedStudent] = await db
      .update(students)
      .set(student)
      .where(eq(students.id, id))
      .returning();
    return updatedStudent;
  }

  async deleteStudent(id: number): Promise<void> {
    await db.delete(students).where(eq(students.id, id));
  }

  async getStudentsByClass(kelas: string): Promise<Student[]> {
    return await db.select().from(students).where(eq(students.kelas, kelas)).orderBy(students.nama);
  }

  // Attendance
  async getAttendance(): Promise<(Attendance & { student: Student })[]> {
    const result = await db
      .select({
        id: attendance.id,
        studentId: attendance.studentId,
        tanggal: attendance.tanggal,
        keterangan: attendance.keterangan,
        createdAt: attendance.createdAt,
        student: students,
      })
      .from(attendance)
      .leftJoin(students, eq(attendance.studentId, students.id))
      .orderBy(desc(attendance.tanggal));
    
    return result.filter(r => r.student !== null) as (Attendance & { student: Student })[];
  }

  async getAttendanceByFilters(filters: { kelas?: string; startDate?: string; endDate?: string }): Promise<(Attendance & { student: Student })[]> {
    let query = db
      .select({
        id: attendance.id,
        studentId: attendance.studentId,
        tanggal: attendance.tanggal,
        keterangan: attendance.keterangan,
        createdAt: attendance.createdAt,
        student: students,
      })
      .from(attendance)
      .leftJoin(students, eq(attendance.studentId, students.id));

    const conditions = [];
    
    if (filters.kelas) {
      conditions.push(eq(students.kelas, filters.kelas));
    }
    if (filters.startDate) {
      conditions.push(gte(attendance.tanggal, filters.startDate));
    }
    if (filters.endDate) {
      conditions.push(lte(attendance.tanggal, filters.endDate));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    const result = await query.orderBy(desc(attendance.tanggal));
    return result.filter(r => r.student !== null) as (Attendance & { student: Student })[];
  }

  async createAttendance(attendanceData: InsertAttendance): Promise<Attendance> {
    const [newAttendance] = await db.insert(attendance).values(attendanceData).returning();
    return newAttendance;
  }

  async updateAttendance(id: number, attendanceData: Partial<InsertAttendance>): Promise<Attendance> {
    const [updatedAttendance] = await db
      .update(attendance)
      .set(attendanceData)
      .where(eq(attendance.id, id))
      .returning();
    return updatedAttendance;
  }

  async deleteAttendance(id: number): Promise<void> {
    await db.delete(attendance).where(eq(attendance.id, id));
  }

  // Incidents
  async getIncidents(): Promise<(Incident & { student: Student })[]> {
    const result = await db
      .select({
        id: incidents.id,
        studentId: incidents.studentId,
        jenisKejadian: incidents.jenisKejadian,
        deskripsi: incidents.deskripsi,
        tanggal: incidents.tanggal,
        createdAt: incidents.createdAt,
        student: students,
      })
      .from(incidents)
      .leftJoin(students, eq(incidents.studentId, students.id))
      .orderBy(desc(incidents.tanggal));
    
    return result.filter(r => r.student !== null) as (Incident & { student: Student })[];
  }

  async getIncidentsByFilters(filters: { kelas?: string; jenisKejadian?: string; tanggal?: string }): Promise<(Incident & { student: Student })[]> {
    let query = db
      .select({
        id: incidents.id,
        studentId: incidents.studentId,
        jenisKejadian: incidents.jenisKejadian,
        deskripsi: incidents.deskripsi,
        tanggal: incidents.tanggal,
        createdAt: incidents.createdAt,
        student: students,
      })
      .from(incidents)
      .leftJoin(students, eq(incidents.studentId, students.id));

    const conditions = [];
    
    if (filters.kelas) {
      conditions.push(eq(students.kelas, filters.kelas));
    }
    if (filters.jenisKejadian) {
      conditions.push(eq(incidents.jenisKejadian, filters.jenisKejadian));
    }
    if (filters.tanggal) {
      conditions.push(eq(incidents.tanggal, filters.tanggal));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }

    const result = await query.orderBy(desc(incidents.tanggal));
    return result.filter(r => r.student !== null) as (Incident & { student: Student })[];
  }

  async createIncident(incident: InsertIncident): Promise<Incident> {
    const [newIncident] = await db.insert(incidents).values(incident).returning();
    return newIncident;
  }

  async updateIncident(id: number, incident: Partial<InsertIncident>): Promise<Incident> {
    const [updatedIncident] = await db
      .update(incidents)
      .set(incident)
      .where(eq(incidents.id, id))
      .returning();
    return updatedIncident;
  }

  async deleteIncident(id: number): Promise<void> {
    await db.delete(incidents).where(eq(incidents.id, id));
  }

  // Reports
  async getAttendanceReport(filters: { kelas?: string; startDate?: string; endDate?: string }): Promise<AttendanceReport[]> {
    let baseQuery = db
      .select({
        studentId: students.id,
        nama: students.nama,
        kelas: students.kelas,
        keterangan: attendance.keterangan,
      })
      .from(students)
      .leftJoin(attendance, eq(students.id, attendance.studentId));

    const conditions = [];
    
    if (filters.kelas) {
      conditions.push(eq(students.kelas, filters.kelas));
    }
    if (filters.startDate && filters.endDate) {
      conditions.push(
        and(
          gte(attendance.tanggal, filters.startDate),
          lte(attendance.tanggal, filters.endDate)
        )
      );
    }

    const rawData = conditions.length > 0 
      ? await baseQuery.where(and(...conditions))
      : await baseQuery;

    // Group by student and count attendance types
    const studentMap = new Map<number, AttendanceReport>();

    rawData.forEach(row => {
      if (!studentMap.has(row.studentId)) {
        studentMap.set(row.studentId, {
          studentId: row.studentId,
          nama: row.nama,
          sakit: 0,
          izin: 0,
          alpa: 0,
          kesiangan: 0,
          bolos: 0,
          status: '',
        });
      }

      const record = studentMap.get(row.studentId)!;
      
      if (row.keterangan) {
        switch (row.keterangan) {
          case 'sakit':
            record.sakit++;
            break;
          case 'izin':
            record.izin++;
            break;
          case 'alpa':
            record.alpa++;
            break;
          case 'kesiangan':
            record.kesiangan++;
            break;
          case 'bolos':
            record.bolos++;
            break;
        }
      }
    });

    // Calculate status based on rules
    const reports = Array.from(studentMap.values()).map(record => {
      let totalPoints = 0;
      
      // Rules: Sakit after 10x, Izin after 3x, others from 1x
      if (record.sakit > 10) totalPoints += record.sakit - 10;
      if (record.izin > 3) totalPoints += record.izin - 3;
      totalPoints += record.alpa + record.kesiangan + record.bolos;

      let status = '';
      if (totalPoints === 0) status = 'Sangat Baik';
      else if (totalPoints <= 3) status = 'Baik';
      else if (totalPoints <= 6) status = 'Sedang';
      else if (totalPoints <= 15) status = 'Kurang';
      else status = 'Buruk';

      return {
        ...record,
        status,
      };
    });

    return reports;
  }

  async getIncidentReport(filters: { kelas?: string; startDate?: string; endDate?: string }): Promise<IncidentReport[]> {
    let baseQuery = db
      .select({
        studentId: students.id,
        nama: students.nama,
        kelas: students.kelas,
        jenisKejadian: incidents.jenisKejadian,
      })
      .from(students)
      .leftJoin(incidents, eq(students.id, incidents.studentId));

    const conditions = [];
    
    if (filters.kelas) {
      conditions.push(eq(students.kelas, filters.kelas));
    }
    if (filters.startDate && filters.endDate) {
      conditions.push(
        and(
          gte(incidents.tanggal, filters.startDate),
          lte(incidents.tanggal, filters.endDate)
        )
      );
    }

    const rawData = conditions.length > 0 
      ? await baseQuery.where(and(...conditions))
      : await baseQuery;

    // Group by student and count incidents
    const studentMap = new Map<number, { 
      studentId: number; 
      nama: string; 
      incidents: string[]; 
    }>();

    rawData.forEach(row => {
      if (!studentMap.has(row.studentId)) {
        studentMap.set(row.studentId, {
          studentId: row.studentId,
          nama: row.nama,
          incidents: [],
        });
      }

      const record = studentMap.get(row.studentId)!;
      if (row.jenisKejadian) {
        record.incidents.push(row.jenisKejadian);
      }
    });

    // Calculate status and format results
    const reports = Array.from(studentMap.values()).map(record => {
      const totalKejadian = record.incidents.length;
      
      // Count incident types
      const incidentCounts = record.incidents.reduce((acc, incident) => {
        acc[incident] = (acc[incident] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      // Format incident description
      const keteranganKejadian = Object.entries(incidentCounts)
        .map(([type, count]) => `${type} (${count}x)`)
        .join(', ') || '-';

      // Determine status based on total incidents
      let status = '';
      if (totalKejadian === 0) status = 'Baik';
      else if (totalKejadian <= 2) status = 'Sedang';
      else if (totalKejadian <= 5) status = 'Kurang';
      else status = 'Buruk';

      return {
        studentId: record.studentId,
        nama: record.nama,
        totalKejadian,
        keteranganKejadian,
        status,
      };
    });

    return reports;
  }
}

export const storage = new DatabaseStorage();
